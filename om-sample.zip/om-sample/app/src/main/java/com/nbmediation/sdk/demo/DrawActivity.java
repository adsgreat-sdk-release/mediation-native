package com.nbmediation.sdk.demo;

import android.content.res.Resources;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;

import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.adsgreat.base.config.Const;
import com.nbmediation.sdk.demo.utils.NewApiUtils;
import com.nbmediation.sdk.nativead.AdInfo;
import com.nbmediation.sdk.nativead.MediaView;
import com.nbmediation.sdk.nativead.NativeAd;
import com.nbmediation.sdk.nativead.NativeAdListener;
import com.nbmediation.sdk.nativead.NativeAdView;
import android.widget.Toast;


public class DrawActivity extends AppCompatActivity {
    private NativeAd nativeAd;
    private View adView;
    private NativeAdView nativeAdView;
    private LinearLayout adContainer;
    private FragmentTransaction fragmentTransaction;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_draw);
        adContainer = findViewById(R.id.ad_container);
        getNativeVideo();
    }

    private void  getNativeVideo(){
        if (nativeAd != null) {
            nativeAd.destroy();
        }
        Toast.makeText(DrawActivity.this,"ad is loading...",Toast.LENGTH_LONG).show();

        nativeAd = new NativeAd(this, NewApiUtils.P_NATIVE, new NativeAdListener() {
            @Override
            public void onAdFailed(String msg) {
                Toast.makeText(DrawActivity.this,"get ad failed!",Toast.LENGTH_LONG).show();
                Const.HANDLER.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        finish();
                    }
                },3000);

            }

            @Override
            public void onAdReady(AdInfo info) {
                //UI布局结构可修改
                //demo: adContainer -> nativeAdView -> adView -> mediaview -> ks content draw
                adContainer.removeAllViews();

                //添加native_ad_layout布局的adview，native_ad_layout布局里写好mediaview
                adView = LayoutInflater.from(DrawActivity.this).inflate(R.layout.draw_ad_layout, null);
                nativeAdView = new NativeAdView(DrawActivity.this);
                nativeAdView.addView(adView);

                //检索mediaview，并设置接收ks content draw
                MediaView mediaView = adView.findViewById(R.id.ad_media);
                nativeAdView.setMediaView(mediaView);
                fragmentTransaction = DrawActivity.this.getSupportFragmentManager().beginTransaction();
                fragmentTransaction.replace(nativeAdView.getMediaView().getId(),(Fragment)info.getObjc()).commit();
                RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(
                        RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);

                //添加nativeAdView到adContainer
                adContainer.addView(nativeAdView, layoutParams);
            }

            @Override
            public void onAdClicked() {

            }
        });
        nativeAd.loadAd();
    }

    public static int dp2px(int dpVal) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                dpVal, Resources.getSystem().getDisplayMetrics());
    }
}